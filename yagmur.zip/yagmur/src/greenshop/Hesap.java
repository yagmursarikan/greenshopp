package greenshop;

public class Hesap {
    private String hesapNo;
    private String kullaniciAdi;
    private double bakiye;

    private String sepet;

    public Hesap(String hesapNo, String kullaniciAdi,double bakiye) {
        this.hesapNo = hesapNo;
        this.kullaniciAdi = kullaniciAdi;
        this.bakiye = bakiye;
    }

    public double getBakiye() {
        return bakiye;
    }

    public void setBakiye(double bakiye) {
        this.bakiye = bakiye;
    }

    public String getHesapNo() {
        return hesapNo;
    }

    public void setHesapNo(String hesapNo) {
        this.hesapNo = hesapNo;
    }

    public String getKullaniciAdi() {
        return kullaniciAdi;
    }

    public void setKullaniciAdi(String kullaniciAdi) {
        this.kullaniciAdi = kullaniciAdi;
    }

    public String getSepet() {


        return sepet;
    }

    public void setSepet(String sepet) {
        this.sepet = sepet;

    }
}
