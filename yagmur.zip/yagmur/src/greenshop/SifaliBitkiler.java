package greenshop;

public class SifaliBitkiler extends DekorasyonBitkileri {

    public SifaliBitkiler(String isim, int sira,int fiyat) {
        super(isim, sira,fiyat);
    }

    @Override
    public int bilgiGoster() {
        return super.bilgiGoster();
    }

}
