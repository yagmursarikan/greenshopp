package greenshop;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        Hesap hesap = new Hesap("199882", "Ayberk SENCAN", 450);
        ArrayList<DekorasyonBitkileri> dekbitkileri = new ArrayList<DekorasyonBitkileri>();
        dekbitkileri.add(new DekorasyonBitkileri("Sans bitkisi", 1, 130));
        dekbitkileri.add(new DekorasyonBitkileri("Sena botanik bitkisi", 2, 157));
        dekbitkileri.add(new DekorasyonBitkileri("Kokina bitkisi", 3, 250));
        dekbitkileri.add(new DekorasyonBitkileri("Ficus Benjamin bitkisi", 4, 369));

        ArrayList<SifaliBitkiler> sifabitkileri = new ArrayList<SifaliBitkiler>();
        sifabitkileri.add(new SifaliBitkiler("Kekik", 1,75));
        sifabitkileri.add(new SifaliBitkiler("Papatya", 2, 95));
        sifabitkileri.add(new SifaliBitkiler("Defne", 3, 120));
        sifabitkileri.add(new SifaliBitkiler("Dereotu", 4, 159));

        String anamenu = "1.Dekarasyon bitkileri\n" +
                "2.Sifali bitkiler\n" +
                "3.Hesabim\n" +
                "4.Programdan cik";
        System.out.println("\n****GREEN SHOP***\n\n");


        for (int i = 0; i < 1; i++) {

            System.out.println(anamenu);
            System.out.println("Isleminizi seciniz:");
            int secim = scanner.nextInt();

            switch (secim) {
                case 1:
                    System.out.println("---Dekarasyon Bitkileri---\n");


                    for (DekorasyonBitkileri dekarasyonBitkileri : dekbitkileri) {

                        System.out.println(dekarasyonBitkileri.sira + ". " + dekarasyonBitkileri.isim);
                    }

                    System.out.println("Bilgi almak istediginiz bitkinin sayisini girin:");
                    int sayi = scanner.nextInt();
                    if (sayi == 1) {
                        dekbitkileri.get(0).bilgiGoster();}
                        System.out.println("Bitkiyi satin almak icin (1)\n Ana menuye donmek icin (2)");
                        int s = scanner.nextInt();
                        if (s == 1) {
                            hesap.setSepet(dekbitkileri.get(0).toString());
                          //  hesap.setBakiye()-=  DekorasyonBitkileri.fiyat;


                            System.out.println("Bitki basariyla satin alindi" + hesap.getSepet());
                            System.out.println("Sepetiniz"+(String)(hesap.getSepet()));
                            i--;
                        }
                        else if(s==2){
                            i--;
                        }

                     else if (sayi == 2) dekbitkileri.get(1).bilgiGoster();
                    else if (sayi == 3) dekbitkileri.get(2).bilgiGoster();
                    else if (sayi == 4) dekbitkileri.get(3).bilgiGoster();
                    else System.out.println("Dogru sayi giriniz");
                    break;

                case 2:
                    System.out.println("---Sifali Bitkiler---\n");

                    for (SifaliBitkiler sifaliBitkiler : sifabitkileri) {
                        System.out.println(sifaliBitkiler.sira + "" + sifaliBitkiler.isim);
                    }
                    System.out.println("Bilgi almak istediginiz bitkinin sayisini girin:");
                    int sayi1 = scanner.nextInt();
                    if (sayi1 == 1) {
                        sifabitkileri.get(0).bilgiGoster();
                        System.out.println("Bitkiyi satin almak icin (1)\n Ana menuye donmek icin (2)");
                        int s1 = scanner.nextInt();
                        if (s1 == 1) {
                            hesap.setSepet(sifabitkileri.get(0).toString());
                            System.out.println("Bitki basariyla satin alindi" + hesap.getSepet());
                        } // burada geridönme fonksiyonlari olucak

                    } else if (sayi1 == 2) sifabitkileri.get(1).bilgiGoster();
                    else if (sayi1 == 3) sifabitkileri.get(2).bilgiGoster();
                    else if (sayi1 == 4) sifabitkileri.get(3).bilgiGoster();
                    else System.out.println("Dogru sayi giriniz");

                    break;

                case 3:
                    System.out.println("---Hesabim---");
                    System.out.println("Isim:" + hesap.getKullaniciAdi());
                    System.out.println("Hesap No:" + hesap.getHesapNo());
                    System.out.println("Bakiye:" + hesap.getBakiye());
                    System.out.println("Sepet:" + hesap.getSepet());
                    break;
            }


        }
    }
}

