package greenshop;

import GreenShop1.BilgiGöster;

public class DekorasyonBitkileri extends BilgiGöster {
    public String isim;
    public int sira;
    public  static int fiyat;

    public DekorasyonBitkileri(String isim, int sira,int fiyat) {

        this.isim = isim;
        this.sira = sira;
        this.fiyat= fiyat;

    }
    public static void dekbitki(){
        System.out.println("ANTORYUM 120tl");
        System.out.println("ZEZE BİTKİSİ 110tl");
    }
    public int bilgiGoster() {
        System.out.println(isim);
        System.out.println(fiyat);

        return 1;
    }

}

