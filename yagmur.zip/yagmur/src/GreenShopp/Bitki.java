package GreenShopp;

public interface Bitki {
     void isim(int b);
     double fiyat(int a);

     public void Bitki_Bilgileri (int bitkino);
}
