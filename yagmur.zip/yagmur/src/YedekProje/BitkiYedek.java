package YedekProje;

public interface BitkiYedek {
    void isim(int b);
    double fiyat(int a);

    public void Bitki_Bilgileri (int bitkino);
}
