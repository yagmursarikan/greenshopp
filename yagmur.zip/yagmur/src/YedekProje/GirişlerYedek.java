package YedekProje;

public abstract class GirişlerYedek {
    public abstract void giriş();
    public abstract void seçenek() throws InterruptedException;

    public static void sepet(int sepet) {
    }
}
