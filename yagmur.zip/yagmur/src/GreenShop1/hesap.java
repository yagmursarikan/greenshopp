package GreenShop1;

public class hesap {
    private String hesapno;
    private String kullanici_adi;
    private String password;
    private double bakiye;
    private double sepet;
    private double fiyat=0;

    public hesap(String kullanici_adi, String password, double bakiye){
      this.kullanici_adi=kullanici_adi;
      this.password=password;
      this.bakiye=bakiye;
    }

    public String getHesapno() {
        return hesapno;
    }

    public void setHesapno(String hesapno) {
        this.hesapno = hesapno;
    }

    public String getKullanici_adi() {
        return kullanici_adi;
    }

    public void setKullanici_adi(String kullanici_adi) {
        this.kullanici_adi = kullanici_adi;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public double getBakiye() {
        return bakiye;
    }

    public void setBakiye(double bakiye) {
        this.bakiye = bakiye;
    }

    public double getFiyat() {
        return fiyat;
    }

    public void setFiyat(double fiyat) {
        this.fiyat = fiyat;
    }

    public double getSepet() {
        sepet += fiyat;
        return sepet;
    }

    public void setSepet(double sepet) {
        this.sepet = sepet;
    }
}
