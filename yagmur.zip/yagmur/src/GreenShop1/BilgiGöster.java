package GreenShop1;

import greenshop.Main;

import java.util.ArrayList;

public class BilgiGöster extends Main {

      public static void bilgigöster(ArrayList Dekbitkiler){

          for ( int i=0; i<Dekbitkiler.size(); i++ ){
            //  System.out.println(dekbitki(arrayLists.toString());
              System.out.println(Dekbitkiler.get(i));
          }
      }
      public static void alım(int islem){
          System.out.println("Satın almak için 1'e basınız \n"+
                  "Diğer bitkilerin bilgilerine bakmak için 2'ye basınız.");
      }
      public static void bilgigöster1(int a){
        System.out.println("ANTORYUM 120TL");
        System.out.println("ZEZE BİTKİSİ 110TL");
        //System.out.println(DekorasyonBitkileri.Dekbitkiler[a]);
      }
      public static void sepet (int b){
          int sepet = 0;
          sepet += DekorasyonBitkileri.dekbitki1(b-1);
          System.out.println("Sepetinizin toplam tutarı = "+sepet);
          return ;
      }
}
