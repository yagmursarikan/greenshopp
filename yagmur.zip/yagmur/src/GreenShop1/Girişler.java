package GreenShop1;

public abstract class Girişler {
    public abstract void giriş();
    public abstract void seçenek() throws InterruptedException;

    public static void sepet(int sepet) {
    }
   // public abstract void ödeme();
}
