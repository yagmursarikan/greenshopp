package GreenShop1;
import java.sql.Array;
import java.util.*;
public class DekorasyonBitkileri extends BilgiGöster {
    public String isim;
    public int sira;
    public  static int fiyat;

    public DekorasyonBitkileri(String isim, int sira,int fiyat) {

        this.isim = isim;
        this.sira = sira;
        this.fiyat= fiyat;

    }
    public static void dekbitki(String arrayLists){
        List<String> Dekbitkiler1 = new ArrayList<>();
        Dekbitkiler1.add("---ANTORYUM---\n");
        Dekbitkiler1.add("Fiyatı 120tl\n");
        Dekbitkiler1.add("Antoryum haftalarca süren kalp şeklindeki çarpıcı" +
                " kırmızı veya pembe çiçeklere sahiptir. \n");
        Dekbitkiler1.add("Çok fazla parlak, dolaylı ışığa ihtiyacı vardır.\n");
        Dekbitkiler1.add("Sulamalar arasında toprağın biraz kurumasını bekleyin.\n");

        List<String> Dekbitkikeri2 = new ArrayList<>();
        Dekbitkikeri2.add(1,("---ZEZE BİTKİSİ---\n"));
        Dekbitkikeri2.add(2,"Fiyatı 11tl\n");
        Dekbitkikeri2.add(3,"Parlak, mumsu görünümlü yapraklara sahiptir.\n");
        Dekbitkikeri2.add(4," Karanlık köşelerde rahatlıkla bakılabilir\n");
        Dekbitkikeri2.add(4,"Birkaç hafta sulamayı unutsanız bile hayatta kalan en " +
                "sert ev bitkilerinden biridir.");
        List<String> Dekbitkiler = new ArrayList<>();
        Dekbitkiler.add("ANTORYUM 120TL");
        Dekbitkiler.add("ZEZE BİTKİSİ 110TL");
        //Dekbitkiler.add(Dekbitkiler1.toString());
    }
    public static int dekbitki1(int a){
        int [] dekbitki1 = {120,110,130};
        //System.out.println(dekbitki1[a]);

        return dekbitki1[a];
    }
}


