package GreenShop1;
import greenshop.Hesap;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main extends BilgiGöster {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        hesap hesabim = new hesap("yağmur sarıkan", "190555",1500);

        List<String> Dekbitkiler1 = new ArrayList<>();
        Dekbitkiler1.add("---ANTORYUM---\n");
        Dekbitkiler1.add("Fiyatı 120tl\n");
        Dekbitkiler1.add("Antoryum haftalarca süren kalp şeklindeki çarpıcı" +
                " kırmızı veya pembe çiçeklere sahiptir. \n");
        Dekbitkiler1.add("Çok fazla parlak, dolaylı ışığa ihtiyacı vardır.\n");
        Dekbitkiler1.add("Sulamalar arasında toprağın biraz kurumasını bekleyin.\n");

        List<String> DekbitkiLeri2 = new ArrayList<>();
        DekbitkiLeri2.add(("---ZEZE BİTKİSİ---\n"));
        DekbitkiLeri2.add("Fiyatı 11tl\n");
        DekbitkiLeri2.add("Parlak, mumsu görünümlü yapraklara sahiptir.\n");
        DekbitkiLeri2.add(" Karanlık köşelerde rahatlıkla bakılabilir\n");
        DekbitkiLeri2.add("Birkaç hafta sulamayı unutsanız bile hayatta kalan en " +
                "sert ev bitkilerinden biridir.");



        String menu = "1-Dekorasyon Bitkileri \n" +
                "2-Şifalı Bitkiler \n" +
                "3-Sepet \n" +
                "4-Programdan çıkmak için 0'a basın";

        System.out.println("GREEN SHOP MAĞAZASINA HOŞGELDİNİZ");
        for (int i = 0; i < 1; i++) {
            System.out.println(menu);
            int islem = scanner.nextInt();

            if (islem == 1) {
                //bilgigöster(ArrayList  <String> Dekbitkikeri2 );
                System.out.println("Bilgi almak istediğiniz bitkinin numarasını giriniz: ");
                int numara = scanner.nextInt();

                for (int j = 0; j < 1; j++) {
                    switch (numara) {
                        case 1:

                            System.out.println(Dekbitkiler1);
                            alım(1);
                            int islem2 = scanner.nextInt();
                            if (islem2 == 1) {
                                System.out.println("Kaç numaralı bitkiyi satın almak istiyorsunuz");
                                int bitkino = scanner.nextInt();
                                BilgiGöster.sepet(bitkino);
                                break;

                            } else if (islem2 == 2) {
                                break;
                            }
                            break;
                        case 2:
                          //  System.out.println(Dekbitkikeri2);
                            j--;
                            break;
                    }
                }
            } else if (islem==2) {

        } else if (islem==3) {

        } else if (islem==0) {

        } else {
                System.out.println("Hatalı seçim yaptınız tekrar deneyiniz");
                return;

            }
        }
    }
}





